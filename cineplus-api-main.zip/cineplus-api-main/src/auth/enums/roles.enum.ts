export enum Role {
  USUARIO = 'USUARIO',
  ADMIN = 'ADMIN',
}
